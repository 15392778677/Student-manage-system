﻿#include "Student mange System.h"


int main() {
	
	while (1) {
		welcome();
		fflush(stdin);
		char ch=getch();
		switch (ch) {
		case '1':
			Input();
			break;
		case '2':
			_print();
			break;
		case '5':
			_calcuate();
			break;
		case '6':
			if (_find() == NULL) {
				printf("*\t    没有找到该学生的信息\t\t*\n");
			}
			else {
				printf("*\t%d  %s  %d\t\t*\n", _find()->s.number, _find()->s.name, _find()->s.score);
			}
			break;
		case '7':
			_mistake();
			break;
		case '8':
			_delete();
			break;
		case '0':
			printf("bye bye\n");
			return 0;
			break;
		}
	}

	return 0;
}
void welcome() {
	          
	printf("*****************************************\n");
	printf("*    欢迎使用高校学生成绩管理系统\t*\n");
	printf("*****************************************\n");
	printf("*\t    请选择功能列表\t\t*\n");
	printf("*****************************************\n");
	printf("*\t    1.录入学生信息\t\t*\n");
	printf("*\t    2.打印学生信息\t\t*\n");
	printf("*\t    5.统计学生人数\t\t*\n");
	printf("*\t    6.查找学生信息\t\t*\n");
	printf("*\t    7.修改学生信息\t\t*\n");
	printf("*\t    8.删除学生信息\t\t*\n");
	printf("*\t    0.退出系统    \t\t*\n");
	printf("*****************************************\n");
}
//录入并保存学生信息
void Input() {
	char ch = '0';
	Linklist* p=NULL;
	while (1) {
		Linklist* node;
		node = (Linklist*)malloc(sizeof(Linklist));

		//头插法
		if (p == NULL) {
			p = node;
			node->next = NULL;
		}
		else
		{
			node->next = p;
			p = node;
		}

		printf("请输入姓名:");
		scanf("%s", node->s.name);
		printf("请输入学号：");
		scanf("%d", &node->s.number);
		printf("请输入成绩：");
		scanf("%d", &node->s.score);
		printf("信息录入成功.\n");
		getchar();
		printf("还有吗？(y/n):");
		scanf("%c", &ch);
		if (ch == 'y') 
		{ 
			continue;
		}
		else if (ch == 'n') break;
	}
	head = p;
	_save();
	system("pause");
	system("cls");
}

//打印学生信息
void _print() {
	printf("*****************************************\n");
	printf("*\t  学号  姓名  成绩\t\t*\n");
	Linklist* p = _read();
	if (p != NULL) {
		while (p != NULL) {
			printf("*\t%d  %s  %d\t\t*\n", p->s.number, p->s.name, p->s.score);
			p = p->next;
		}
	}
	else {
		printf("*\t    没有学生信息\t\t*\n");
	}
	head = NULL;
	printf("*****************************************\n");
	system("pause");
	system("cls");
}

//保存学生信息
void _save(){
	Linklist* p = head;
	FILE* file=fopen("student.txt", "a");
	while (p != NULL) {
		fprintf(file, "%d  %s  %d\n", p->s.number, p->s.name, p->s.score);
		p = p->next;
	}
	fclose(file);
	head = NULL;
	system("pause");
	system("cls");
}

//读取学生信息
Linklist* _read() {
	Linklist* phead = (Linklist*)malloc(sizeof(Linklist)),*tail;
	tail = phead;
	FILE* file = fopen("student.txt", "rt");
	//读取信息存在链表中
	while (1) {
		Linklist* node = (Linklist*)malloc(sizeof(Linklist));
		if (EOF == fscanf(file, "%d %s %d", &node->s.number, node->s.name, &node->s.score)) {
			tail->next = NULL;
			break;
		}
		tail->next = node;
		tail = node;
	}
	fclose(file);
	printf("*\t    读取信息成功\t\t*\n");
	return phead->next;
}

//统计学生人数
void _calcuate() {
	 Linklist* p = _read();
	 int num = 0;
	 while (p != NULL) {
		 p = p->next;
		 num++;
	 }
	 printf("*\t    共有%d人\t\t*\n",num);
	 system("pause");
	 system("cls");
}

//查找学生信息
Linklist* _find() {

	Linklist* p= _read();
	head = p;
	int number;
	printf("请输入学生学号：");
	scanf("%d", &number);
	while (p!=NULL) {
		if (number == p->s.number) {
			return p;
			break;
		}
		p = p->next;
	}
	return NULL;
}

//修改学生信息
void _mistake() {
    Linklist* p = _find();
	Linklist* t = head;
	int n=0;
	if (p == NULL) 
	{
		printf("*\t    没有找到该学生的信息\t\t*\n");
	}
	else
	{
		
			printf("请问您是要修改姓名/成绩？（1/2)");
			scanf("%d", &n);
			while (1) {
			if (n == 1) 
			{
				printf("请输入您要修改的学生姓名:");
				scanf("%s", p->s.name);
				break;
			}
			else if (n == 2) {
				printf("请输入您要修改的学生成绩：");
				scanf("%d", &p->s.score);
				break;
			}
			else {
				printf("请输入（1/2）:\n");
				scanf("%d", &n);
			}
		}
			printf("*\t    修改信息成功\t\t*\n");
	}
	FILE* file=fopen("student.txt", "w");
	while (t != NULL) {
		fprintf(file, "%d  %s  %d\n", t->s.number, t->s.name, t->s.score);
		t = t->next;
	}
	head = NULL;
	fclose(file);
	system("pause");
	system("cls");
}

//删除学生信息
//采用 文件写入为 'w'的写入方式可以实现覆盖，以删除之前的信息
void _delete() 
   {
	
	Linklist* p = _read(),* t,* phead;
	phead = p;
	int number=0;
	printf("请输删除学生学号：");
	scanf("%d", &number);
	if (p->s.number == number) {
		t = p;
		p = p->next;
		free(t);
	}
	else {
		while (p->next != NULL)
		{
			if (p->next->s.number == number)
			{
				t = p->next;
				p->next = t->next;
				free(t);
			}
			if(p->next!=NULL)
			{
			p = p->next;
			}
         }
	}
	FILE* file = fopen("student.txt", "w");
	while (phead != NULL)
	{
		fprintf(file, "%d  %s  %d\n", phead->s.number, phead->s.name, p->s.score);
		phead = phead->next;
	}
	fclose(file);
	head = NULL;
	printf("*\t    删除信息成功\t\t*\n");
	system("pause");
	system("cls");

}